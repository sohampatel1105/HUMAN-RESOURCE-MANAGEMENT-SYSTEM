import { pgTable, text, serial, integer, boolean, timestamp, date, doublePrecision } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(), // Employee ID or Email
  password: text("password").notNull(),
  role: text("role").notNull().default("employee"), // "admin" | "employee"
  createdAt: timestamp("created_at").defaultNow(),
});

export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull().unique(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  department: text("department").notNull(),
  designation: text("designation").notNull(),
  joiningDate: date("joining_date").notNull(),
  salaryBasic: integer("salary_basic").notNull(),
  salaryHRA: integer("salary_hra").notNull(),
  salaryPF: integer("salary_pf").notNull(),
  emergencyContact: text("emergency_contact"),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  date: date("date").notNull(),
  status: text("status").notNull(), // "present", "absent", "leave"
  checkInTime: timestamp("check_in_time"),
  checkOutTime: timestamp("check_out_time"),
});

export const leaves = pgTable("leaves", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  type: text("type").notNull(), // "sick", "casual"
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("pending"), // "pending", "approved", "rejected"
});

export const payroll = pgTable("payroll", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").references(() => employees.id).notNull(),
  month: text("month").notNull(), // e.g., "2023-10"
  basic: integer("basic").notNull(),
  allowances: integer("allowances").notNull(),
  deductions: integer("deductions").notNull(),
  netPay: integer("net_pay").notNull(),
  status: text("status").notNull().default("processed"), // "processed", "paid"
  generatedAt: timestamp("generated_at").defaultNow(),
});

// === RELATIONS ===

export const employeesRelations = relations(employees, ({ one, many }) => ({
  user: one(users, {
    fields: [employees.userId],
    references: [users.id],
  }),
  attendance: many(attendance),
  leaves: many(leaves),
  payroll: many(payroll),
}));

export const attendanceRelations = relations(attendance, ({ one }) => ({
  employee: one(employees, {
    fields: [attendance.employeeId],
    references: [employees.id],
  }),
}));

export const leavesRelations = relations(leaves, ({ one }) => ({
  employee: one(employees, {
    fields: [leaves.employeeId],
    references: [employees.id],
  }),
}));

export const payrollRelations = relations(payroll, ({ one }) => ({
  employee: one(employees, {
    fields: [payroll.employeeId],
    references: [employees.id],
  }),
}));

// === INSERT SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertEmployeeSchema = createInsertSchema(employees).omit({ id: true });
export const insertAttendanceSchema = createInsertSchema(attendance).omit({ id: true });
export const insertLeaveSchema = createInsertSchema(leaves).omit({ id: true, status: true });
export const insertPayrollSchema = createInsertSchema(payroll).omit({ id: true, generatedAt: true });

// === EXPLICIT API CONTRACT TYPES ===

export type User = typeof users.$inferSelect;
export type Employee = typeof employees.$inferSelect;
export type Attendance = typeof attendance.$inferSelect;
export type Leave = typeof leaves.$inferSelect;
export type Payroll = typeof payroll.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type InsertLeave = z.infer<typeof insertLeaveSchema>;
export type InsertPayroll = z.infer<typeof insertPayrollSchema>;

export type LoginRequest = { username: string; password: string };
export type CreateEmployeeRequest = InsertEmployee & { user: InsertUser }; // Combined for atomic creation

import { z } from 'zod';
import { 
  insertUserSchema, 
  insertEmployeeSchema, 
  insertAttendanceSchema, 
  insertLeaveSchema, 
  insertPayrollSchema,
  employees,
  attendance,
  leaves,
  payroll
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/login',
      input: z.object({
        username: z.string(),
        password: z.string(),
      }),
      responses: {
        200: z.any(), // User object
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/logout',
      responses: {
        200: z.void(),
      },
    },
    user: {
      method: 'GET' as const,
      path: '/api/user',
      responses: {
        200: z.any(),
        401: errorSchemas.unauthorized,
      },
    }
  },
  employees: {
    list: {
      method: 'GET' as const,
      path: '/api/employees',
      responses: {
        200: z.array(z.custom<typeof employees.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/employees/:id',
      responses: {
        200: z.custom<typeof employees.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/employees',
      input: insertEmployeeSchema.extend({
        username: z.string(),
        password: z.string(),
        role: z.enum(['admin', 'employee']),
      }),
      responses: {
        201: z.custom<typeof employees.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/employees/:id',
      input: insertEmployeeSchema.partial(),
      responses: {
        200: z.custom<typeof employees.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  attendance: {
    list: {
      method: 'GET' as const,
      path: '/api/attendance',
      input: z.object({
        employeeId: z.string().optional(),
        month: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof attendance.$inferSelect>()),
      },
    },
    checkIn: {
      method: 'POST' as const,
      path: '/api/attendance/check-in',
      input: z.object({ employeeId: z.number() }),
      responses: {
        201: z.custom<typeof attendance.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    checkOut: {
      method: 'POST' as const,
      path: '/api/attendance/check-out',
      input: z.object({ employeeId: z.number() }),
      responses: {
        200: z.custom<typeof attendance.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  leaves: {
    list: {
      method: 'GET' as const,
      path: '/api/leaves',
      input: z.object({
        employeeId: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof leaves.$inferSelect>()),
      },
    },
    apply: {
      method: 'POST' as const,
      path: '/api/leaves',
      input: insertLeaveSchema,
      responses: {
        201: z.custom<typeof leaves.$inferSelect>(),
      },
    },
    updateStatus: {
      method: 'PATCH' as const,
      path: '/api/leaves/:id/status',
      input: z.object({ status: z.enum(['approved', 'rejected']) }),
      responses: {
        200: z.custom<typeof leaves.$inferSelect>(),
      },
    },
  },
  payroll: {
    list: {
      method: 'GET' as const,
      path: '/api/payroll',
      input: z.object({
        employeeId: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof payroll.$inferSelect>()),
      },
    },
    process: {
      method: 'POST' as const,
      path: '/api/payroll/process',
      input: z.object({ month: z.string() }),
      responses: {
        201: z.array(z.custom<typeof payroll.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { format } from "date-fns";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth (Passport)
  setupAuth(app);

  // Middleware to check auth
  const requireAuth = (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) return next();
    res.status(401).json({ message: "Unauthorized" });
  };

  const requireAdmin = (req: any, res: any, next: any) => {
    if (req.isAuthenticated() && req.user.role === 'admin') return next();
    res.status(403).json({ message: "Forbidden" });
  };

  // === EMPLOYEES ===
  app.get(api.employees.list.path, requireAuth, async (req, res) => {
    // Employees can see themselves, Admins can see all
    if (req.user.role === 'admin') {
      const employees = await storage.getEmployees();
      res.json(employees);
    } else {
      const employee = await storage.getEmployeeByUserId(req.user.id);
      res.json(employee ? [employee] : []);
    }
  });

  app.get(api.employees.get.path, requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    const employee = await storage.getEmployee(id);
    if (!employee) return res.status(404).json({ message: "Employee not found" });
    
    // Authorization check
    if (req.user.role !== 'admin') {
      const currentEmployee = await storage.getEmployeeByUserId(req.user.id);
      if (currentEmployee?.id !== id) return res.status(403).json({ message: "Forbidden" });
    }
    
    res.json(employee);
  });

  app.post(api.employees.create.path, requireAdmin, async (req, res) => {
    try {
      const { username, password, role, ...employeeData } = api.employees.create.input.parse(req.body);
      
      // Create User first
      const user = await storage.createUser({ username, password, role });
      
      // Create Employee profile
      const employee = await storage.createEmployee({
        ...employeeData,
        userId: user.id
      });
      
      res.status(201).json(employee);
    } catch (e) {
      if (e instanceof z.ZodError) {
        res.status(400).json(e.errors);
      } else {
        res.status(500).json({ message: "Internal Server Error" });
      }
    }
  });

  app.put(api.employees.update.path, requireAdmin, async (req, res) => {
    const id = parseInt(req.params.id);
    const updates = api.employees.update.input.parse(req.body);
    try {
      const updated = await storage.updateEmployee(id, updates);
      res.json(updated);
    } catch (e) {
      res.status(404).json({ message: "Employee not found" });
    }
  });

  // === ATTENDANCE ===
  app.get(api.attendance.list.path, requireAuth, async (req, res) => {
    const currentEmployee = await storage.getEmployeeByUserId(req.user.id);
    if (!currentEmployee) return res.status(404).json({ message: "Employee profile not found" });

    // Admins can query any employee, Employees only themselves
    let targetEmployeeId = currentEmployee.id;
    if (req.user.role === 'admin' && req.query.employeeId) {
      targetEmployeeId = parseInt(req.query.employeeId as string);
    }

    const records = await storage.getAttendance(targetEmployeeId);
    res.json(records);
  });

  app.post(api.attendance.checkIn.path, requireAuth, async (req, res) => {
    const currentEmployee = await storage.getEmployeeByUserId(req.user.id);
    if (!currentEmployee) return res.status(404).json({ message: "Employee profile not found" });
    
    const today = format(new Date(), 'yyyy-MM-dd');
    const existing = await storage.getAttendanceByDate(currentEmployee.id, today);
    
    if (existing) return res.status(400).json({ message: "Already checked in today" });

    const record = await storage.createAttendance({
      employeeId: currentEmployee.id,
      date: today,
      status: 'present',
      checkInTime: new Date(),
    });
    
    res.status(201).json(record);
  });

  app.post(api.attendance.checkOut.path, requireAuth, async (req, res) => {
    const currentEmployee = await storage.getEmployeeByUserId(req.user.id);
    if (!currentEmployee) return res.status(404).json({ message: "Employee profile not found" });
    
    const today = format(new Date(), 'yyyy-MM-dd');
    const existing = await storage.getAttendanceByDate(currentEmployee.id, today);
    
    if (!existing) return res.status(400).json({ message: "No check-in record found for today" });
    if (existing.checkOutTime) return res.status(400).json({ message: "Already checked out" });

    const updated = await storage.updateAttendance(existing.id, {
      checkOutTime: new Date()
    });
    
    res.json(updated);
  });

  // === LEAVES ===
  app.get(api.leaves.list.path, requireAuth, async (req, res) => {
    if (req.user.role === 'admin') {
      const leaves = await storage.getLeaves(req.query.employeeId ? parseInt(req.query.employeeId as string) : undefined);
      res.json(leaves);
    } else {
      const currentEmployee = await storage.getEmployeeByUserId(req.user.id);
      if (!currentEmployee) return res.status(404).json({ message: "Profile not found" });
      const leaves = await storage.getLeaves(currentEmployee.id);
      res.json(leaves);
    }
  });

  app.post(api.leaves.apply.path, requireAuth, async (req, res) => {
    const currentEmployee = await storage.getEmployeeByUserId(req.user.id);
    if (!currentEmployee) return res.status(404).json({ message: "Profile not found" });

    const input = api.leaves.apply.input.parse(req.body);
    const leave = await storage.createLeave({
      ...input,
      employeeId: currentEmployee.id,
      status: 'pending'
    });
    res.status(201).json(leave);
  });

  app.patch(api.leaves.updateStatus.path, requireAdmin, async (req, res) => {
    const id = parseInt(req.params.id);
    const { status } = req.body;
    const updated = await storage.updateLeaveStatus(id, status);
    res.json(updated);
  });

  // === PAYROLL ===
  app.get(api.payroll.list.path, requireAuth, async (req, res) => {
    if (req.user.role === 'admin') {
      const records = await storage.getPayroll();
      res.json(records);
    } else {
      const currentEmployee = await storage.getEmployeeByUserId(req.user.id);
      if (!currentEmployee) return res.status(404).json({ message: "Profile not found" });
      const records = await storage.getPayroll(currentEmployee.id);
      res.json(records);
    }
  });

  app.post(api.payroll.process.path, requireAdmin, async (req, res) => {
    const { month } = req.body;
    const employees = await storage.getEmployees();
    const payrolls = [];

    // Simple payroll logic
    for (const emp of employees) {
      const netPay = emp.salaryBasic + emp.salaryHRA - emp.salaryPF;
      const record = await storage.createPayroll({
        employeeId: emp.id,
        month,
        basic: emp.salaryBasic,
        allowances: emp.salaryHRA,
        deductions: emp.salaryPF,
        netPay,
        status: 'processed'
      });
      payrolls.push(record);
    }
    
    res.status(201).json(payrolls);
  });

  await seedDatabase();

  return httpServer;
}

export async function seedDatabase() {
  const users = await storage.getUserByUsername('admin');
  if (!users) {
    // Create Admin
    const adminUser = await storage.createUser({ 
      username: 'admin', 
      password: 'password123', 
      role: 'admin' 
    });
    
    await storage.createEmployee({
      userId: adminUser.id,
      fullName: 'System Admin',
      email: 'admin@company.com',
      department: 'HR',
      designation: 'HR Manager',
      joiningDate: '2023-01-01',
      salaryBasic: 50000,
      salaryHRA: 20000,
      salaryPF: 5000,
      emergencyContact: '999',
      phone: '1234567890'
    });

    // Create Employee
    const empUser = await storage.createUser({ 
      username: 'E001', 
      password: 'password123', 
      role: 'employee' 
    });

    await storage.createEmployee({
      userId: empUser.id,
      fullName: 'John Doe',
      email: 'john@company.com',
      department: 'Engineering',
      designation: 'Software Engineer',
      joiningDate: '2023-06-15',
      salaryBasic: 40000,
      salaryHRA: 15000,
      salaryPF: 4000,
      emergencyContact: '911',
      phone: '0987654321'
    });
  }
}

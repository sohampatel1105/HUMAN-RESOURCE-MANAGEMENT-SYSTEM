import { db } from "./db";
import {
  users, employees, attendance, leaves, payroll,
  type User, type Employee, type Attendance, type Leave, type Payroll,
  type InsertUser, type InsertEmployee, type InsertAttendance, type InsertLeave, type InsertPayroll
} from "@shared/schema";
import { eq, and, gte, lte } from "drizzle-orm";

import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getEmployees(): Promise<Employee[]>;
  getEmployee(id: number): Promise<Employee | undefined>;
  getEmployeeByUserId(userId: number): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: number, employee: Partial<InsertEmployee>): Promise<Employee>;

  getAttendance(employeeId: number): Promise<Attendance[]>;
  getAttendanceByDate(employeeId: number, date: string): Promise<Attendance | undefined>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendance: Partial<InsertAttendance>): Promise<Attendance>;

  getLeaves(employeeId?: number): Promise<Leave[]>;
  createLeave(leave: InsertLeave): Promise<Leave>;
  updateLeaveStatus(id: number, status: string): Promise<Leave>;

  getPayroll(employeeId?: number): Promise<Payroll[]>;
  createPayroll(payroll: InsertPayroll): Promise<Payroll>;

  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  // Employees
  async getEmployees(): Promise<Employee[]> {
    return await db.select().from(employees);
  }

  async getEmployee(id: number): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.id, id));
    return employee;
  }

  async getEmployeeByUserId(userId: number): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.userId, userId));
    return employee;
  }

  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    const [newEmployee] = await db.insert(employees).values(employee).returning();
    return newEmployee;
  }

  async updateEmployee(id: number, employeeUpdates: Partial<InsertEmployee>): Promise<Employee> {
    const [updated] = await db.update(employees).set(employeeUpdates).where(eq(employees.id, id)).returning();
    return updated;
  }

  // Attendance
  async getAttendance(employeeId: number): Promise<Attendance[]> {
    return await db.select().from(attendance).where(eq(attendance.employeeId, employeeId));
  }

  async getAttendanceByDate(employeeId: number, date: string): Promise<Attendance | undefined> {
    const [record] = await db.select().from(attendance)
      .where(and(eq(attendance.employeeId, employeeId), eq(attendance.date, date)));
    return record;
  }

  async createAttendance(record: InsertAttendance): Promise<Attendance> {
    const [newRecord] = await db.insert(attendance).values(record).returning();
    return newRecord;
  }

  async updateAttendance(id: number, updates: Partial<InsertAttendance>): Promise<Attendance> {
    const [updated] = await db.update(attendance).set(updates).where(eq(attendance.id, id)).returning();
    return updated;
  }

  // Leaves
  async getLeaves(employeeId?: number): Promise<Leave[]> {
    if (employeeId) {
      return await db.select().from(leaves).where(eq(leaves.employeeId, employeeId));
    }
    return await db.select().from(leaves);
  }

  async createLeave(leave: InsertLeave): Promise<Leave> {
    const [newLeave] = await db.insert(leaves).values(leave).returning();
    return newLeave;
  }

  async updateLeaveStatus(id: number, status: string): Promise<Leave> {
    const [updated] = await db.update(leaves).set({ status }).where(eq(leaves.id, id)).returning();
    return updated;
  }

  // Payroll
  async getPayroll(employeeId?: number): Promise<Payroll[]> {
    if (employeeId) {
      return await db.select().from(payroll).where(eq(payroll.employeeId, employeeId));
    }
    return await db.select().from(payroll);
  }

  async createPayroll(record: InsertPayroll): Promise<Payroll> {
    const [newRecord] = await db.insert(payroll).values(record).returning();
    return newRecord;
  }
}

export const storage = new DatabaseStorage();

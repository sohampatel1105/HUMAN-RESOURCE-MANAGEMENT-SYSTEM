## Packages
recharts | Dashboard analytics and reporting charts
date-fns | Date formatting and manipulation for attendance/leaves
framer-motion | Smooth animations for page transitions and modals

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}

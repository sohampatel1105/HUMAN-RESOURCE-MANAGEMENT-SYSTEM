import { useAttendance } from "@/hooks/use-attendance";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function Attendance() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const { attendance, isLoading } = useAttendance(isAdmin ? undefined : 1); // Mock ID

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-display">Attendance Records</h1>
        <p className="text-muted-foreground">Track daily check-ins and check-outs</p>
      </div>

      <Card className="shadow-md border-border/50">
        <CardHeader>
          <CardTitle>History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {attendance.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No attendance records found.</p>
            ) : (
              attendance.map((record) => (
                <div key={record.id} className="flex items-center justify-between p-4 rounded-xl border border-border/50 hover:bg-accent/30 transition-colors">
                  <div className="flex flex-col">
                    <span className="font-semibold text-lg">{format(new Date(record.date), "MMMM dd, yyyy")}</span>
                    <span className="text-sm text-muted-foreground">{format(new Date(record.date), "EEEE")}</span>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Check In</p>
                      <p className="font-mono font-medium">
                        {record.checkInTime ? format(new Date(record.checkInTime), "hh:mm a") : "--:--"}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Check Out</p>
                      <p className="font-mono font-medium">
                        {record.checkOutTime ? format(new Date(record.checkOutTime), "hh:mm a") : "--:--"}
                      </p>
                    </div>
                    <div>
                      <Badge variant={record.status === 'present' ? "default" : "destructive"}>
                        {record.status}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { Settings as SettingsIcon, User, Bell, Lock, Shield } from "lucide-react";
import { Card as UICard, CardHeader as UICardHeader, CardTitle as UICardTitle, CardContent as UICardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/hooks/use-auth";

export default function Settings() {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage your account and application preferences</p>
      </div>

      <div className="grid gap-6 max-w-2xl">
        <UICard>
          <UICardHeader>
            <UICardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Profile Information
            </UICardTitle>
          </UICardHeader>
          <UICardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Username</Label>
              <Input value={user?.username} readOnly />
            </div>
            <div className="space-y-2">
              <Label>Role</Label>
              <Input value={user?.role} readOnly className="capitalize" />
            </div>
          </UICardContent>
        </UICard>

        <UICard>
          <UICardHeader>
            <UICardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Notifications
            </UICardTitle>
          </UICardHeader>
          <UICardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Email Notifications</Label>
                <p className="text-sm text-muted-foreground">Receive daily attendance summaries</p>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Push Notifications</Label>
                <p className="text-sm text-muted-foreground">Notify on leave status changes</p>
              </div>
              <Switch defaultChecked />
            </div>
          </UICardContent>
        </UICard>
      </div>
    </div>
  );
}

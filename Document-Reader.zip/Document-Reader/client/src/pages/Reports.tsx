import { useQuery } from "@tanstack/react-query";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  DollarSign 
} from "lucide-react";
import { Card as UICard, CardHeader as UICardHeader, CardTitle as UICardTitle, CardContent as UICardContent } from "@/components/ui/card";
import { api } from "@shared/routes";

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

export default function Reports() {
  const { data: employees } = useQuery({
    queryKey: [api.employees.list.path],
    queryFn: async () => {
      const res = await fetch(api.employees.list.path);
      return res.json();
    }
  });

  const { data: payrolls } = useQuery({
    queryKey: [api.payroll.list.path],
    queryFn: async () => {
      const res = await fetch(api.payroll.list.path);
      return res.json();
    }
  });

  // Simple dept distribution data
  const deptData = employees?.reduce((acc: any[], emp: any) => {
    const existing = acc.find(d => d.name === emp.department);
    if (existing) existing.value++;
    else acc.push({ name: emp.department, value: 1 });
    return acc;
  }, []) || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Reports & Analytics</h1>
        <p className="text-muted-foreground">Company-wide performance and financial metrics</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <UICard>
          <UICardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <UICardTitle className="text-sm font-medium">Headcount</UICardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </UICardHeader>
          <UICardContent>
            <div className="text-2xl font-bold">{employees?.length || 0}</div>
          </UICardContent>
        </UICard>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <UICard>
          <UICardHeader>
            <UICardTitle>Department Distribution</UICardTitle>
          </UICardHeader>
          <UICardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={deptData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {deptData.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </UICardContent>
        </UICard>

        <UICard>
          <UICardHeader>
            <UICardTitle>Monthly Salary Expense</UICardTitle>
          </UICardHeader>
          <UICardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={payrolls}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="netPay" fill="#0056b3" />
              </BarChart>
            </ResponsiveContainer>
          </UICardContent>
        </UICard>
      </div>
    </div>
  );
}

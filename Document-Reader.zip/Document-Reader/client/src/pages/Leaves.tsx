import { useState } from "react";
import { useLeaves } from "@/hooks/use-leaves";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertLeaveSchema } from "@shared/schema";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Plus } from "lucide-react";
import { format } from "date-fns";

const applyLeaveSchema = insertLeaveSchema.extend({
  employeeId: z.coerce.number(),
  startDate: z.coerce.date(),
  endDate: z.coerce.date(),
});

type ApplyFormValues = z.infer<typeof applyLeaveSchema>;

export default function Leaves() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const { leaves, applyLeave, isApplying, updateLeaveStatus } = useLeaves(isAdmin ? undefined : 1); // Mock ID
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const form = useForm<ApplyFormValues>({
    resolver: zodResolver(applyLeaveSchema),
    defaultValues: {
      employeeId: 1, // Mock
      type: "casual",
      reason: "",
    }
  });

  const onSubmit = (data: ApplyFormValues) => {
    // Convert Dates to YYYY-MM-DD strings for API
    const apiData = {
      ...data,
      startDate: data.startDate.toISOString().split('T')[0],
      endDate: data.endDate.toISOString().split('T')[0],
    };

    applyLeave(apiData as any, {
      onSuccess: () => {
        setIsDialogOpen(false);
        form.reset();
      }
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display">Leave Management</h1>
          <p className="text-muted-foreground">Track and manage leave requests</p>
        </div>

        {!isAdmin && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg" className="shadow-lg shadow-primary/20">
                <Plus className="w-5 h-5 mr-2" />
                Apply Leave
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Apply for Leave</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Leave Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="casual">Casual Leave</SelectItem>
                            <SelectItem value="sick">Sick Leave</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start Date</FormLabel>
                          <FormControl><Input type="date" {...field} value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Date</FormLabel>
                          <FormControl><Input type="date" {...field} value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="reason"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reason</FormLabel>
                        <FormControl><Textarea {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full" disabled={isApplying}>
                    {isApplying ? "Submitting..." : "Submit Request"}
                  </Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid gap-4">
        {leaves.map((leave) => (
          <Card key={leave.id} className="shadow-sm border-border/50 hover:shadow-md transition-all">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <span className="font-semibold text-lg capitalize">{leave.type} Leave</span>
                    <Badge variant={
                      leave.status === 'approved' ? 'default' : 
                      leave.status === 'rejected' ? 'destructive' : 
                      'outline'
                    }>
                      {leave.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {format(new Date(leave.startDate), "MMM dd")} - {format(new Date(leave.endDate), "MMM dd, yyyy")}
                  </p>
                  <p className="mt-2 text-sm">{leave.reason}</p>
                </div>

                {isAdmin && leave.status === 'pending' && (
                  <div className="flex gap-3">
                    <Button 
                      variant="outline" 
                      onClick={() => updateLeaveStatus({ id: leave.id, status: 'rejected' })}
                      className="text-red-500 hover:text-red-600 hover:bg-red-50"
                    >
                      Reject
                    </Button>
                    <Button 
                      onClick={() => updateLeaveStatus({ id: leave.id, status: 'approved' })}
                      className="bg-emerald-600 hover:bg-emerald-700"
                    >
                      Approve
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
        {leaves.length === 0 && (
          <div className="text-center py-12 text-muted-foreground bg-accent/20 rounded-xl">
            No leave requests found
          </div>
        )}
      </div>
    </div>
  );
}

import { useAuth } from "@/hooks/use-auth";
import { useAttendance } from "@/hooks/use-attendance";
import { useLeaves } from "@/hooks/use-leaves";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarCheck, CalendarDays, Clock, CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from "recharts";

export default function Dashboard() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const { checkIn, checkOut, attendance, isCheckingIn, isCheckingOut } = useAttendance(isAdmin ? undefined : 1); // Mock ID for now, real app would resolve from user context
  
  // Dummy data for charts
  const attendanceData = [
    { day: "Mon", present: 45, absent: 5 },
    { day: "Tue", present: 48, absent: 2 },
    { day: "Wed", present: 47, absent: 3 },
    { day: "Thu", present: 46, absent: 4 },
    { day: "Fri", present: 44, absent: 6 },
  ];

  if (!user) return null;

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display text-foreground">
            Good Morning, {user.username} 👋
          </h1>
          <p className="text-muted-foreground mt-1">
            {format(new Date(), "EEEE, MMMM do, yyyy")}
          </p>
        </div>
        
        {!isAdmin && (
          <div className="flex gap-3">
            <Button 
              size="lg"
              className="bg-emerald-600 hover:bg-emerald-700 shadow-lg shadow-emerald-600/20"
              onClick={() => checkIn({ employeeId: 1 })}
              disabled={isCheckingIn}
            >
              <CheckCircle2 className="w-5 h-5 mr-2" />
              Check In
            </Button>
            <Button 
              size="lg"
              variant="destructive"
              className="shadow-lg shadow-red-500/20"
              onClick={() => checkOut({ employeeId: 1 })}
              disabled={isCheckingOut}
            >
              <XCircle className="w-5 h-5 mr-2" />
              Check Out
            </Button>
          </div>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatsCard 
          title="Attendance"
          value="92%"
          description="Average this month"
          icon={CalendarCheck}
          trend="+2.5%"
          trendUp={true}
        />
        <StatsCard 
          title="Leave Balance"
          value="12 Days"
          description="Remaining this year"
          icon={CalendarDays}
          trend="-2 days"
          trendUp={false}
        />
        <StatsCard 
          title="Working Hours"
          value="164 Hrs"
          description="Total this month"
          icon={Clock}
          trend="On track"
          trendUp={true}
        />
      </div>

      {/* Main Content Area */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Recent Activity / Chart */}
        <Card className="shadow-lg border-border/50">
          <CardHeader>
            <CardTitle>Attendance Overview</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={attendanceData}>
                <XAxis dataKey="day" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip cursor={{ fill: 'transparent' }} />
                <Bar dataKey="present" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Quick Actions / Notifications */}
        <div className="space-y-6">
          <Card className="shadow-lg border-border/50">
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3].map((_, i) => (
                  <div key={i} className="flex items-start gap-4 p-3 rounded-lg hover:bg-accent/50 transition-colors">
                    <div className="w-2 h-2 mt-2 rounded-full bg-primary" />
                    <div>
                      <p className="font-medium">Checked in at 09:00 AM</p>
                      <p className="text-sm text-muted-foreground">Today</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatsCard({ title, value, description, icon: Icon, trend, trendUp }: any) {
  return (
    <Card className="card-hover border-border/50">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <h3 className="text-3xl font-bold mt-2 font-display">{value}</h3>
          </div>
          <div className="p-3 bg-primary/10 rounded-xl text-primary">
            <Icon className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4 flex items-center text-sm">
          <span className={trendUp ? "text-emerald-600 font-medium" : "text-red-500 font-medium"}>
            {trend}
          </span>
          <span className="text-muted-foreground ml-2">{description}</span>
        </div>
      </CardContent>
    </Card>
  );
}

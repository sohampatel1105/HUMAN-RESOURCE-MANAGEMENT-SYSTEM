import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Receipt, 
  Download, 
  FileText, 
  Search,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription
} from "@/components/ui/button"; // Note: Card is actually from @/components/ui/card, fixing in next step
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { api, buildUrl } from "@shared/routes";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Manual import fix for Card components since they might not be in UI folder correctly based on App.tsx imports
import { Card as UICard, CardHeader as UICardHeader, CardTitle as UICardTitle, CardContent as UICardContent } from "@/components/ui/card";

export default function Payroll() {
  const { user } = useAuth();
  const { toast } = useToast();
  const isAdmin = user?.role === "admin";

  const { data: payrolls, isLoading } = useQuery({
    queryKey: [api.payroll.list.path],
    queryFn: async () => {
      const res = await fetch(api.payroll.list.path);
      if (!res.ok) throw new Error("Failed to fetch payroll");
      return res.json();
    }
  });

  const processMutation = useMutation({
    mutationFn: async (month: string) => {
      const res = await fetch(api.payroll.process.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ month }),
      });
      if (!res.ok) throw new Error("Failed to process payroll");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.payroll.list.path] });
      toast({ title: "Success", description: "Payroll processed successfully" });
    }
  });

  const currentMonth = new Date().toISOString().slice(0, 7);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Payroll</h1>
          <p className="text-muted-foreground">Manage and view salary distributions</p>
        </div>
        {isAdmin && (
          <Button 
            onClick={() => processMutation.mutate(currentMonth)}
            disabled={processMutation.isPending}
          >
            {processMutation.isPending ? "Processing..." : "Process Current Month"}
          </Button>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <UICard>
          <UICardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <UICardTitle className="text-sm font-medium">Total Distributed</UICardTitle>
            <Receipt className="h-4 w-4 text-muted-foreground" />
          </UICardHeader>
          <UICardContent>
            <div className="text-2xl font-bold">
              ${payrolls?.reduce((acc: number, p: any) => acc + p.netPay, 0).toLocaleString() || 0}
            </div>
          </UICardContent>
        </UICard>
      </div>

      <UICard>
        <UICardHeader>
          <UICardTitle>Payroll History</UICardTitle>
        </UICardHeader>
        <UICardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month</TableHead>
                <TableHead>Basic</TableHead>
                <TableHead>Allowances</TableHead>
                <TableHead>Deductions</TableHead>
                <TableHead>Net Pay</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payrolls?.map((p: any) => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.month}</TableCell>
                  <TableCell>${p.basic}</TableCell>
                  <TableCell>${p.allowances}</TableCell>
                  <TableCell>${p.deductions}</TableCell>
                  <TableCell className="font-bold">${p.netPay}</TableCell>
                  <TableCell>
                    <Badge variant={p.status === 'paid' ? 'default' : 'secondary'}>
                      {p.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon">
                      <Download className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </UICardContent>
      </UICard>
    </div>
  );
}

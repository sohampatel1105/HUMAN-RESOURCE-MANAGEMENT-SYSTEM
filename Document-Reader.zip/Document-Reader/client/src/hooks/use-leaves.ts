import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertLeave } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useLeaves(employeeId?: number) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const list = useQuery({
    queryKey: [api.leaves.list.path, employeeId ? String(employeeId) : "all"],
    queryFn: async () => {
      const url = employeeId 
        ? `${api.leaves.list.path}?employeeId=${employeeId}` 
        : api.leaves.list.path;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch leaves");
      return api.leaves.list.responses[200].parse(await res.json());
    },
  });

  const apply = useMutation({
    mutationFn: async (data: InsertLeave) => {
      const res = await fetch(api.leaves.apply.path, {
        method: api.leaves.apply.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to apply leave");
      return api.leaves.apply.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.leaves.list.path] });
      toast({ title: "Submitted", description: "Leave request submitted successfully" });
    },
    onError: (err) => toast({ variant: "destructive", title: "Error", description: err.message }),
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: 'approved' | 'rejected' }) => {
      const url = buildUrl(api.leaves.updateStatus.path, { id });
      const res = await fetch(url, {
        method: api.leaves.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed to update status");
      return api.leaves.updateStatus.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.leaves.list.path] });
      toast({ title: "Updated", description: "Leave status updated successfully" });
    },
  });

  return {
    leaves: list.data || [],
    isLoading: list.isLoading,
    applyLeave: apply.mutate,
    isApplying: apply.isPending,
    updateLeaveStatus: updateStatus.mutate,
    isUpdating: updateStatus.isPending
  };
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useAttendance(employeeId?: number) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const queryKey = [api.attendance.list.path, employeeId ? String(employeeId) : "all"];

  const list = useQuery({
    queryKey,
    queryFn: async () => {
      const url = employeeId 
        ? `${api.attendance.list.path}?employeeId=${employeeId}` 
        : api.attendance.list.path;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch attendance");
      return api.attendance.list.responses[200].parse(await res.json());
    },
  });

  const checkIn = useMutation({
    mutationFn: async (data: { employeeId: number }) => {
      const res = await fetch(api.attendance.checkIn.path, {
        method: api.attendance.checkIn.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Check-in failed");
      return api.attendance.checkIn.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.attendance.list.path] });
      toast({ title: "Checked In", description: "Have a great day at work!" });
    },
    onError: (err) => toast({ variant: "destructive", title: "Error", description: err.message }),
  });

  const checkOut = useMutation({
    mutationFn: async (data: { employeeId: number }) => {
      const res = await fetch(api.attendance.checkOut.path, {
        method: api.attendance.checkOut.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Check-out failed");
      return api.attendance.checkOut.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.attendance.list.path] });
      toast({ title: "Checked Out", description: "See you tomorrow!" });
    },
    onError: (err) => toast({ variant: "destructive", title: "Error", description: err.message }),
  });

  return {
    attendance: list.data || [],
    isLoading: list.isLoading,
    checkIn: checkIn.mutate,
    isCheckingIn: checkIn.isPending,
    checkOut: checkOut.mutate,
    isCheckingOut: checkOut.isPending,
  };
}

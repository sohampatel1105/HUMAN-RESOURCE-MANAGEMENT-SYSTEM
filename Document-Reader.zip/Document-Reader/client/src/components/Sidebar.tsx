import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Users, 
  CalendarCheck, 
  CalendarDays, 
  Receipt, 
  BarChart3, 
  Settings, 
  LogOut,
  Menu,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { useMobile } from "@/hooks/use-mobile";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface NavItemProps {
  href: string;
  icon: React.ElementType;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

function NavItem({ href, icon: Icon, label, active, onClick }: NavItemProps) {
  return (
    <Link 
      href={href} 
      className={cn(
        "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
        active 
          ? "bg-primary text-primary-foreground shadow-md shadow-primary/25 font-semibold" 
          : "text-muted-foreground hover:bg-accent hover:text-foreground"
      )}
      onClick={onClick}
    >
      <Icon className={cn("w-5 h-5", active ? "text-primary-foreground" : "group-hover:text-primary")} />
      <span>{label}</span>
    </Link>
  );
}

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const isMobile = useMobile();
  const [open, setOpen] = useState(false);

  const isAdmin = user?.role === "admin";

  const navItems = [
    { href: "/", icon: LayoutDashboard, label: "Dashboard" },
    ...(isAdmin ? [{ href: "/employees", icon: Users, label: "Employees" }] : []),
    { href: "/attendance", icon: CalendarCheck, label: "Attendance" },
    { href: "/leaves", icon: CalendarDays, label: "Leaves" },
    { href: "/payroll", icon: Receipt, label: "Payroll" },
    ...(isAdmin ? [{ href: "/reports", icon: BarChart3, label: "Reports" }] : []),
    { href: "/settings", icon: Settings, label: "Settings" },
  ];

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-card border-r border-border/50">
      <div className="p-6 border-b border-border/50">
        <h1 className="text-2xl font-display font-bold text-foreground tracking-tight flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Users className="w-5 h-5 text-white" />
          </div>
          HR<span className="text-primary">Master</span>
        </h1>
      </div>

      <div className="flex-1 overflow-y-auto py-6 px-4 space-y-1">
        {navItems.map((item) => (
          <NavItem 
            key={item.href}
            {...item}
            active={location === item.href}
            onClick={() => setOpen(false)}
          />
        ))}
      </div>

      <div className="p-4 border-t border-border/50">
        <div className="bg-accent/50 rounded-xl p-4 mb-4">
          <p className="text-sm font-medium text-foreground">{user?.username}</p>
          <p className="text-xs text-muted-foreground capitalize">{user?.role}</p>
        </div>
        <Button 
          variant="ghost" 
          className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
          onClick={() => logout()}
        >
          <LogOut className="w-4 h-4 mr-2" />
          Logout
        </Button>
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <div className="fixed top-0 left-0 w-full h-16 bg-background border-b border-border flex items-center px-4 z-50">
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="w-6 h-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-80">
            <SidebarContent />
          </SheetContent>
        </Sheet>
        <span className="ml-4 font-display font-bold text-lg">HR Master</span>
      </div>
    );
  }

  return (
    <aside className="w-72 h-screen fixed left-0 top-0 z-30 hidden md:block">
      <SidebarContent />
    </aside>
  );
}
